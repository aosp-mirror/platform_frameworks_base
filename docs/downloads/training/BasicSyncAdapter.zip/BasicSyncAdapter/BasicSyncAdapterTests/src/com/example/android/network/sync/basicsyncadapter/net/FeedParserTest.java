package com.example.android.network.sync.basicsyncadapter.net;

import junit.framework.TestCase;

public class FeedParserTest extends TestCase {
    public FeedParserTest() {
        super();
    }

//    public void testEntriesEqualById() {
//        FeedParser.Entry e1 = new FeedParser.Entry("alpha", "Aardvark", "Bear", "Cat");
//        FeedParser.Entry e2 = new FeedParser.Entry("alpha", "Dog", "Elephant", "Faun");
//        assertEquals(e1, e2);
//    }
//
//    public void testEntriesHashById() {
//        FeedParser.Entry e1 = new FeedParser.Entry("alpha", "Aardvark", "Bear", "Cat");
//        FeedParser.Entry e2 = new FeedParser.Entry("alpha", "Dog", "Elephant", "Faun");
//        assertEquals(e1.hashCode(), e2.hashCode());
//    }
}