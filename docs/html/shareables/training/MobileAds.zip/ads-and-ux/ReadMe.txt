This sample demonstrates the integration of an mobile ad SDK with your application.  In this case,
AdMob is used.

The application has the following external dependencies.  In order to build, be sure to obtain these
JAR files and put them under the libs directory.
1. AdMob SDK
   http://code.google.com/mobile/ads/download.html
2. ViewPager depends on the Android Support Package v4 or above.
   http://developer.android.com/sdk/compatibility-library.html